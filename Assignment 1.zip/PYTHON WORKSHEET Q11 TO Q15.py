#!/usr/bin/env python
# coding: utf-8

# Q.)11 WRITE A PYTHON PROGRAM TO FIND THE FACTORIAL OF A NUMBER

# In[26]:


no = int(input("Enter any number"))
factorial=1
if no < 0:
    print("Factorial do not exist")
elif no == 0:
    print("Factorial is 1")  #We all know Factorial 0! is 1
else:
    
    for i in range(1,no+1):
        factorial = factorial * i
    print("The factorial of",no,"is",factorial) 


# Q.12 WRITE A PYTHON PROGRAM TO FIND WHETHER A NUMBER IS PRIME OR COMPOSITE

# In[25]:


no = int(input("Enter any number: "))

if no > 1:
    for i in range(2,no):
        if (no % i) == 0:
            print(no,"is composite")
            break
        else:
            print(no,"is prime")
            
else:
    
    print(no,"is composite")


# Q 13. WRITE A PYTHON PROGRAM TO CHECK WHETHER THE STRING IS PALINDROME OR NOT.

# In[32]:


def is_palindrome(s):
    if len(s) < 1:
        return True
    else:
        if s[0] == s[-1]:
            return is_palindrome(s[1:-1])
        else:
            return False
a=str(input("Enter string:"))
if(is_palindrome(a)==True):
    print("String is a palindrome!")
else:
    print("String isn't a palindrome!")


# Q.14 WRITE A PYTHON PROGRAM TO FIND OUT THIRD SIDE OF A RIGHT ANGLED TRIANGLE.

# In[34]:


from math import sqrt
print("Input lengths of shorter triangle sides:")
a = float(input("a: "))
b = float(input("b: "))

c = sqrt(a**2 + b**2) # FROM PYTHAGORUS THEOREM 
print("The length of the hypotenuse c is", c )


# Q.15 WRITE A PYTHON PROGRAM TO PRINT THE PREQUENCY OF EACH OF THE CHARACTER PRESENT IN THE GIVEN   STRING

# In[36]:


# initializing string 
_str = "Antarctica"
  
# using naive method to get count 
# of each element in string 
all_freq = {}
  
for i in _str:
    if i in all_freq:
        all_freq[i] += 1
    else:
        all_freq[i] = 1
        
print ("Count of all characters in Antarctica is :\n "
                                        +  str(all_freq))


# In[ ]:




